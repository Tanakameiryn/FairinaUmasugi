<?php
// Kode untuk melakukan konfirmasi pembayaran
if (isset($_GET['id'])) {
  // Mengupdate status_bayar menjadi 1 (sudah dibayar)
  $idPemesanan = $_GET['id'];
  mysqli_query($koneksi, "UPDATE pemesanan SET status_bayar = 1 WHERE id_pemesanan = '$idPemesanan'");

  // Redirect kembali ke halaman pesanan.php
  header("Location: pesanan.php");
  exit();
}
?>
