-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Agu 2023 pada 11.25
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbpemesanan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan`
--

CREATE TABLE `pemesanan` (
  `id_pemesanan` int(50) NOT NULL,
  `tanggal_pemesanan` date NOT NULL,
  `total_belanja` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pemesanan`
--

INSERT INTO `pemesanan` (`id_pemesanan`, `tanggal_pemesanan`, `total_belanja`) VALUES
(47, '2023-07-08', 17000),
(48, '2023-07-08', 15000),
(49, '2023-07-08', 12000),
(50, '2023-07-21', 30000),
(53, '2023-07-22', 45000),
(54, '2023-07-22', 45000),
(55, '2023-07-28', 15000),
(56, '2023-08-26', 25000),
(57, '2023-08-30', 15000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan_produk`
--

CREATE TABLE `pemesanan_produk` (
  `id_pemesanan_produk` int(50) NOT NULL,
  `id_pemesanan` int(50) NOT NULL,
  `id_menu` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `jumlah` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pemesanan_produk`
--

INSERT INTO `pemesanan_produk` (`id_pemesanan_produk`, `id_pemesanan`, `id_menu`, `username`, `jumlah`) VALUES
(7, 32, '9', '', 1),
(8, 32, '11', '', 1),
(9, 33, '16', '', 1),
(10, 33, '6', '', 1),
(11, 34, '13', '', 1),
(12, 34, '8', '', 1),
(13, 34, '9', '', 1),
(14, 34, '17', '', 1),
(15, 35, '9', '', 2),
(16, 35, '14', '', 1),
(17, 36, '8', '', 1),
(18, 37, '13', '', 1),
(19, 37, '16', '', 1),
(20, 38, '8', '', 1),
(21, 39, '9', '', 1),
(22, 39, '16', '', 1),
(23, 40, '10', '', 1),
(24, 40, '14', '', 1),
(25, 41, '17', '', 1),
(26, 41, '10', '', 1),
(27, 41, '9', '', 2),
(28, 42, '9', '', 1),
(29, 42, '14', '', 1),
(30, 42, '7', '', 1),
(31, 42, '17', '', 1),
(32, 43, '16', '', 1),
(33, 43, '7', '', 1),
(34, 44, '17', '', 1),
(35, 45, '7', '', 2),
(36, 46, '7', '', 1),
(37, 47, '8', '', 1),
(38, 48, '24', '', 1),
(39, 49, '6', '', 1),
(40, 50, '27', '', 1),
(41, 50, '36', '', 1),
(42, 51, '29', '', 1),
(43, 52, '38', '', 1),
(44, 53, '29', '', 2),
(45, 53, '40', '', 1),
(46, 54, '41', '', 1),
(47, 54, '38', '', 2),
(48, 55, '29', '', 1),
(49, 56, '29', '', 1),
(50, 56, '26', '', 1),
(51, 57, '24', '', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_menu` int(50) NOT NULL,
  `nama_menu` varchar(50) NOT NULL,
  `jenis_menu` varchar(50) NOT NULL,
  `stok` int(50) NOT NULL,
  `harga` int(50) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_menu`, `nama_menu`, `jenis_menu`, `stok`, `harga`, `gambar`) VALUES
(24, 'ICE COFFE', 'Minuman', 40, 15000, 'R_capucino.jpeg'),
(26, 'HOT COFFE', 'Minuman', 40, 10000, 'R_kopi.jpeg'),
(29, 'BATAGOR', 'Makanan', 70, 15000, 'R_batagor.jpeg'),
(38, 'PISANG', 'Makanan', 70, 15000, 'R_nugget.jpeg'),
(39, 'POP ICE', 'Minuman', 40, 5000, 'R_popice.jpeg'),
(40, 'ICE BOBA', 'Minuman', 70, 15000, 'R_boba.jpeg'),
(41, 'BOBA MILK TEA', 'Minuman', 40, 15000, 'R_boba3.jpeg'),
(42, 'FRENCH FRIES', 'Makanan', 50, 15000, 'R_ken.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `nama_lengkap` varchar(25) NOT NULL,
  `jenis_kelamin` varchar(25) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(25) NOT NULL,
  `hp` varchar(25) NOT NULL,
  `status` enum('admin','user','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama_lengkap`, `jenis_kelamin`, `tanggal_lahir`, `alamat`, `hp`, `status`) VALUES
(1, 'd.o', 'kyungsoo12', 'Doh Kyung soo', 'Laki-Laki', '1993-01-12', 'Stain, Ambon', '081233445566', 'admin'),
(2, 'nana', 'nana30', 'Tanaka Meiryn', 'perempuan', '1993-06-30', ' Ayudes, Ambon', '082233445566', 'user'),
(3, 'slwken', 'slwken123', 'Intan Pristi Arifin', 'perempuan', '2001-11-11', 'Batu Merah, Ambon', '081311001100', 'admin'),
(4, 'irene', 'irene2904', 'bae joo hyun', 'perempuan', '1991-03-29', 'Tulehu,ambon', '082303291991', 'user'),
(5, 'seulgi', 'akang2', 'kang seul gi', 'perempuan', '1994-02-10', 'Tulehu,ambon', '081233445566', 'user'),
(6, 'wendy', 'wendol01', 'son seung wan', 'perempuan', '1994-02-21', 'Stain, Ambon', '082244556677', 'user'),
(7, 'Haechan', '060600', 'lee dong hyuck', 'laki-laki', '2000-06-06', ' Ayudes, Ambon', '081266778899', 'user'),
(14, 'user', '1234567', 'username', 'Laki-Laki', '2023-08-30', 'home', '00998888', 'user'),
(15, '', '', '', '', '0000-00-00', '', '', ''),
(16, 'user', '2121', 'username', 'Perempuan', '2023-08-30', 'home', '081327817384', 'user'),
(17, 'admin', '', 'nnnnn', 'Perempuan', '2023-08-30', 'home', '081327817384', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id_pemesanan`);

--
-- Indeks untuk tabel `pemesanan_produk`
--
ALTER TABLE `pemesanan_produk`
  ADD PRIMARY KEY (`id_pemesanan_produk`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id_pemesanan` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT untuk tabel `pemesanan_produk`
--
ALTER TABLE `pemesanan_produk`
  MODIFY `id_pemesanan_produk` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_menu` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
